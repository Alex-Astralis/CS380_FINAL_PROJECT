// Copyright Epic Games, Inc. All Rights Reserved.

#include "CS380_FINAL_PROJECT.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, CS380_FINAL_PROJECT, "CS380_FINAL_PROJECT" );
 